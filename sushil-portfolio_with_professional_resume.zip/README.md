# 🌐 Sushil Deepak Patale - Portfolio

This is my personal portfolio website showcasing:
- About Me
- Experience
- Projects
- Skills
- Contact Information

## 🚀 Tech Stack
- HTML5
- CSS3
- JavaScript

## 📦 Deployment
1. Clone the repo  
   ```bash
   git clone https://github.com/your-username/sushil-portfolio.git
   ```
2. Open `index.html` in browser OR host with GitHub Pages.

## 📌 Live Demo
[👉 Click Here](https://your-username.github.io/sushil-portfolio)
